package com.example.florapulse;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        textView = findViewById(R.id.textView);


        Plant plant = new Plant("Basilico", 60, 22, 300);


        String info = "Pianta: " + plant.getName() +
                "\nUmidità: " + plant.getHumidity() +
                "\nTemperatura: " + plant.getTemperature() +
                "\nLuce: " + plant.getLight();

        textView.setText(info);
    }
}