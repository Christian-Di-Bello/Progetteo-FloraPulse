package com.example.florapulse;

public class Plant {

    private String name;
    private float humidity;
    private float temperature;
    private float light;

    public Plant() {}

    public Plant(String name, float humidity, float temperature, float light) {
        this.name = name;
        this.humidity = humidity;
        this.temperature = temperature;
        this.light = light;
    }

    public String getName() {
        return name;
    }

    public float getHumidity() {
        return humidity;
    }

    public float getTemperature() {
        return temperature;
    }

    public float getLight() {
        return light;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHumidity(float humidity) {
        this.humidity = humidity;
    }

    public void setTemperature(float temperature) {
        this.temperature = temperature;
    }

    public void setLight(float light) {
        this.light = light;
    }
}